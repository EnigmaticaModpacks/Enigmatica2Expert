CODE
	- boni/The Slime Knights for the fancy multiple breaking animation on using the drill
	- malte0811 for the amazing port of wire rendering to 1.8.9's model system and all the bugfixes
	- AtomicBlom for porting *everything* to 1.11.2!

LOCALIZATION
	- zh_CN: 3TUSK, Amamiya-Nagisa, bakaxyf, CannonFotter, crafteverywhere, IamAchang, Joccob, LYDfalse, UUUii
	- ru_RU: lex1975
	- zh_TW: xaxa123