# ME Upgrade

![Connect to your me network](item:extracells:oc.upgrade@2)

The me upgrade can be placed into [robots](/%LANGUAGE%/block/robot.md) and [drones](/%LANGUAGE%/item/drone.md). The upgrade connect wireless to your me system. Put this upgrade or a [robot](/%LANGUAGE%/block/robot.md)/[drone](/%LANGUAGE%/item/drone.md) into your ae security station to link it with your network. The ranged depents on the tier of the upgrade.


Tier 1: 0.5x access point range.
Tier 2: access point range.
Tier 3: infinity ranger, over dimensions