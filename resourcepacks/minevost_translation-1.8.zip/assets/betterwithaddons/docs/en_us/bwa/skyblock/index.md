# Help! I'm on a Skyblock and I don't know what to do!

## Age of Vanilla
Iron can be obtained rarely from Zombies and less rarely from Iron Golems.
A cauldron can be used earlier with a bit of ingenuity.
Goal: Creating a Windmill and a Nether Portal
 * [Dirt](dirt.md)
 * [Plants](plants.md)
 * [Animals](animals.md)
 * [Nether Portal](portal.md)

## Age of the Nether
A saw can be made from tanned leather. It enables advanced carpentry, and increases drops in a mobfarm.
Goal: Creating a Hibachi
 * [Netherrack](netherrack.md)
 * [Hellfire Dust](hellfire.md)
 * [Gold](gold.md)
 * [Redstone](redstone.md)
 * [Blaze Powder](blaze.md)
 * [Lava](lava.md)

## Age of Fire
Goal: Creating a functional Kiln
 * [Clay](clay.md)
 * [Cobwebs](webs.md)
 * [Dead Plants](deadbush.md)
 * [Soul Sand](soulsand.md)
 * [Quartz](quartz.md)

## Age of Terracotta
 * [Diamonds](diamond.md)
 * [The End Portal](end.md)

## A New Age
 * [End Stone](endstone.md)
 * [Gravel](gravel.md)
 * [Sand](sand.md)