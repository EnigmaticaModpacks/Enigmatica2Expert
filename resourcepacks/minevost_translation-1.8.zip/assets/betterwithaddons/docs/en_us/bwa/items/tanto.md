# Tanto

![Tanto](item:betterwithaddons:tanto@0)

The Tanto is a an ordinary dagger, a little weaker than a Diamond Sword, but when holding right-click, you will take some damage. If you have less than 6 hearts remaining (this is equivalent to the Hurt threshold of Hardcore Injury), hitting an enemy will deal extra damage and bestow a speed boost.