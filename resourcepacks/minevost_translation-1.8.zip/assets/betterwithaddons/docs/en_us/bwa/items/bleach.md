# Wood Bleach and Stain

![Wood Bleach](item:betterwithaddons:decomat@1)

Wood Bleach can be made from Bonemeal and Hemp Oil in a Cauldron. When rendered with Wood Planks in a Cauldron, the planks will be stained one shade lighter than what they currently are.
For example, Oak Planks will become Birch Planks.

![Wood Stain](item:betterwithaddons:decomat@2)

Wood Stain functions identical and is cooked from Ink Sacks instead. It will stain wood darker.