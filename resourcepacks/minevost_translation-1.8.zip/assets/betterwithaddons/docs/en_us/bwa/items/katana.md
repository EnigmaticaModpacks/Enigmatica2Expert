# Katana

![Katana](item:betterwithaddons:katana@0)

The Katana is a an ordinary longsword. It's a little stronger than a Diamond Sword.