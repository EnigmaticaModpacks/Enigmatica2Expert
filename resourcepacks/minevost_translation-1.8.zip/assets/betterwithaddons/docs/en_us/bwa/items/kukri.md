# Kukri

![Kukri](item:betterwithaddons:steel_kukri@0)

The Kukri is a curved blade which is especially useful for harvesting trees. It cuts like butter through any natural wood and leaves, but is somewhat unsuitable for cutting carpentry.
Additionally, it being a blade, it makes a pretty good melee weapon. Saplings and Logs harvested by this tool will be collected instantly, or if that's not possible, dropped at your feet.

When right-clicked with, the Kukri will attempt to place a Sapling from your inventory where you're looking.