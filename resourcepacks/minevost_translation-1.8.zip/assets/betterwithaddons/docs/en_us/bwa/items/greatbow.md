# Greatbow

![Greatbow](item:betterwithaddons:greatbow@0)

Greatbows are larger, heavier versions of Compound Bows. It takes much longer to pull back the string of a Greatbow, but it fires much farther than an ordinary bow and deals high damage.

![Greatarrow](item:betterwithaddons:greatarrow@0)

Greatarrows are needed to fire Greatbows. On impact, arrows fired with sufficient strength will break softer blocks like dirt, leaving small impact craters. The strength of an impact can be increased by enchanting the Greatbow with Power. More levels of Power will allow the bow to break harder blocks.