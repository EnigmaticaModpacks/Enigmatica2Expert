# Match Pick

![Match Pick](item:betterwithaddons:steel_matchpick@0)

The Match Pick is in all aspects equivalent to a regular pick of the same level. But when right-clicked with, it will attempt to place a Torch from your inventory where you're looking. If it cannot place a torch, or while sneaking, it will ignite the ground instead, making it an apt way to create light sources in the Nether.