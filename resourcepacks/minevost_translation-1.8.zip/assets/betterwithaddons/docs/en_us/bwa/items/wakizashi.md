# Wakizashi

![Wakizashi](item:betterwithaddons:wakizashi@0)

The Wakizashi is a an ordinary shortsword, but when an enemy has less than one quarter of it's health remaining, it will deal extra damage.