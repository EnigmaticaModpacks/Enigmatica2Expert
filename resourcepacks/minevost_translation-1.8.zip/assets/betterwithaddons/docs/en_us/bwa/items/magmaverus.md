# Magma Cream Verus

![Magma Cream Verus](item:betterwithaddons:material@6)

Magma Cream Verus is a material that drops from Shulkers. It can be crafted into [Magma Verus Blocks](../blocks/magmaverus.md).