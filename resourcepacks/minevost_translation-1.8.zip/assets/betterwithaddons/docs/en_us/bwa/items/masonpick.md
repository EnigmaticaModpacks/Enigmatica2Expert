# Mason Pick

![Mason Pick](item:betterwithaddons:steel_masonpick@0)

The Mason Pick is a tool specifically made for quick building. It breaks any processed stone blocks very quickly and immediately picks them up. If picking them up would not be possible, the items will drop at your feet.

When right-clicked with, the Mason Pick will attempt to place any processed stone block (Bricks, Stairs, Slabs, ...) from your inventory where you're looking.