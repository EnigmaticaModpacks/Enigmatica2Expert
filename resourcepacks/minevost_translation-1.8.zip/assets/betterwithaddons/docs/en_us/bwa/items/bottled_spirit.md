# Bottle of Japanese Ancestry

![Bottle of Japanese Ancestry](item:betterwithaddons:ancestry_bottle@0)

This bottle contains [spirits](../mechanics/spirits.md). Each bottle can hold exactly ![8](var:betterwithaddons:spirits_per_bottle) spirits.
The bottle can be applied to Soul Sand by right-clicking to [infuse](../blocks/ancestrysand.md) the spirits into the Soul Sand.