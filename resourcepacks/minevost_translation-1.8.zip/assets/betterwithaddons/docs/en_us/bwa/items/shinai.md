# Shinai

![Shinai](item:betterwithaddons:shinai@0)

The Shinai is a short bamboo sword. It won't deal any damage to creatures, but it can apply some knockback on hit. This property makes it perfect for herding animals without a lead.

If a single punch would kill a creature, the Shinai can be used for the last hit instead. This would make for some humiliating footage if used on your friends.