# Machete

![Machete](item:betterwithaddons:steel_machete@0)

The machete is a blade repurposed into a cutting tool. It cuts through thick foliage like Tall Grass, Leaves, Vines and Webs easily.
The blade is as sharp as Shears tend to be, so the harvested plantlife will be harvested as is, and immediently stashed in your pack if possible. If your pack is full, the harvested items will drop at your feet.

When right-clicked with, the Kukri will attempt to place Vines from your inventory where you're looking.