# Items

## Materials
 * [Magma Cream Verus](magmaverus.md)
 * [Condensed Items](condensed.md)
 * [Wood Bleach and Stain](bleach.md)
 * [Salt](salt.md)
 * [Bottle of Japanese Ancestry](bottled_spirit.md)

## Tools
 * [Machete](machete.md)
 * [Matchpick](matchpick.md)
 * [Kukri](kukri.md)
 * [Spade](spade.md)
 * [Carpenter Saw](carpentersaw.md)
 * [Mason Pick](masonpick.md)

## Warfare
 * [Greatbow](greatbow.md)
 * [Shinai](shinai.md)
 * [Katana](katana.md)
 * [Wakizashi](wakizashi.md)
 * [Tanto](tanto.md)
 * [Yumi](yumi.md)
