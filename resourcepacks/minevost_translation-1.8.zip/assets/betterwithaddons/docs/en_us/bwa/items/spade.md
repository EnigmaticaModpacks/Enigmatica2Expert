# Spade

![Spade](item:betterwithaddons:steel_spade@0)

Sometimes a normal ~~spoon~~ shovel might not suffice for tasks like terraforming a large area. The spade has a wide head made specifically for slinging dirt around.
When you dig up some soil it will immediately be picked up, if there's space in your pack, otherwise it will drop at your feet.
Right-clicking with the Spade in hand will then place some soil from your inventory. It's eye for an eye, dirt for a dirt.