# Carpenter Saw

![Carpenter Saw](item:betterwithaddons:steel_carpentersaw@0)

The Carpenter Saw is a tool specifically made for quick building. It cuts any wooden furniture or planks very quickly and immediately picks them up. If picking them up would not be possible, the items will drop at your feet.

When right-clicked with, the Carpenter Saw will attempt to place any processed wooden block (Planks, Stairs, Slabs, ...) from your inventory where you're looking.