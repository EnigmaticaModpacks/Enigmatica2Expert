# Salt

![Salt](item:betterwithaddons:salt@0)

Salt Crystals can be ground into dust in a millstone. Sometimes. It feels like this is an ancient relic from a day long past.