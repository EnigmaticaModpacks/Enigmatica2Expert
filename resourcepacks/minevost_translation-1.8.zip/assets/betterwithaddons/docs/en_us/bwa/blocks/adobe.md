# Adobe

![Adobe](block:betterwithaddons:adobe@0)

Adobe is a primitive building block that can be manufactured in bulk very quickly from common materials. Adobe consists mostly of clay and sand, with hay, straw or animal dung mixed in as binder.
The variant of Adobe created depends on the mixture. Some mixtures are better suited for building than others. All mixtures share that they must be dried in bright sunlight after being placed to harden them.