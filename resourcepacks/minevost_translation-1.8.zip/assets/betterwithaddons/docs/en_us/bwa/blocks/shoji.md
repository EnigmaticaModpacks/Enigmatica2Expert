# Shoji and Fusuma

![Shoji](block:betterwithaddons:shoji@0)

Shoji is a decorative paper screen. It's not very hard to break, and it connects to one another like Iron Bars or Glass Panes.

![Fusuma](block:betterwithaddons:fusuma@0)

Fusuma functions just like Shoji, and Fusuma and Shoji connect to each other. Additionally, Fusuma can be painted by right-clicking it with an empty hand. Most designs are taller or wider than one block.