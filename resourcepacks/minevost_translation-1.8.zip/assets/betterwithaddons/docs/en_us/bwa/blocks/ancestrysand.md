# Infused Soul Sand

![Infused Soul Sand](block:betterwithaddons:ancestry_sand@0)

Infused Soul Sand can be created by right-clicking a block of Soul Sand with a Bottle of Japanese Ancestry. The Soul Sand block will then turn red, and the spirits will be transferred into it.
Infused Soul Sand attracts nearby free spirits and absorbs them on contact.

Normally, Soul Sand binds souls to itself. However, should mechanical power be applied to it from any side, the souls within will begin to stir and grow restless. This can be used to funnel them into a hopper with a Soul Sand filter containing glass bottles, where they can fill the bottles at the usual rate.