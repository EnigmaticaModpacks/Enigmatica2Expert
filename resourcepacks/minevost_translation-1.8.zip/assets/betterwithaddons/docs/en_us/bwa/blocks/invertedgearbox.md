# Clutchbox

![Clutchbox](block:betterwithaddons:inverted_gearbox@0)

The Clutchbox works nearly identical to an ordinary gearbox, except that there is only output and instead 5 inputs. The input opposite to the output is the drive shaft, power will propagate freely through the gearbox from the drive shaft to the output.
Unless, the Clutchbox has mechanical power fed into any of the other sides, then the Clutchbox will not propagate any mechanical energy.

Note that this is nigh useless for any real purpose, unless somehow, you live in a world where redstone is scarce...