# Bamboo

![Bamboo](block:betterwithaddons:bamboo@0)

Bamboo is a type of grass and a useful material for construction and crafting. It grows similar to sugarcane, but will spread horizontally and grows up to 4 blocks high.
It does not grow naturally in the world and must be created by infusing a similar crop with japanese spirit.

After harvesting it, it is still not ready to be used for most common applications, it must first be processed.