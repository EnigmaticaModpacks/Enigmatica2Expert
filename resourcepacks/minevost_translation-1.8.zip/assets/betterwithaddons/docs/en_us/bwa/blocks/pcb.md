# PCB

![PCB](block:betterwithaddons:pcb_block@0)

PCBs allow for better control where redstone dust will connect, for much more compact designs. The connection sides can be changed by right-clicking the top of the block.
PCBs can also be rotated by turntables.