# Banner Detector

![Banner Detector](block:betterwithaddons:banner_detector@0)

The Banner Detector does exactly what you think it does. It can see Banners up to a certain distance. Whether the banners are placed or on people's heads doesn't matter to it. It can also see past most transparent-ish blocks.

When placed next to lattice under the influence of a worldscale, it won't be able to be broken. You can have the same effect by placing it behind iron bars. The container for the banner it uses as comparison can only be accessed from the back of the detector.