# Lanterns

![Wooden Lantern](block:betterwithaddons:wood_lamp@0)
![Iron Lantern](block:betterwithaddons:wrought_lamp@0)

Lanterns are purely decorative light sources. Before they emit light, they must be lit with Flint and Steel. They can also be extinguished again by activating them with an empty hand.