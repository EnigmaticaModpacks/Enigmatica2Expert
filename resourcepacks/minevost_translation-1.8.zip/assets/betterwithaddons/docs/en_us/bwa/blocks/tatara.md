# Tatara

![Tatara](block:betterwithaddons:tatara@0)

The Tatara is a traditional japanese furnace, used in the smelting of iron sand to create Tamahagane and Hocho-Tetsu.
To construct it, follow the schematics written underneath.

![Schematic](betterwithaddons:docs/imgs/tatara.png)

In order to begin creation of japanese steel, you must first obtain Iron Sand. The Tatara must be heated by burning Rice Ashes.
Iron Sand will be smelted into Kera, which must be broken apart into raw Tamahagane, raw Hocho-Tetsu and iron.