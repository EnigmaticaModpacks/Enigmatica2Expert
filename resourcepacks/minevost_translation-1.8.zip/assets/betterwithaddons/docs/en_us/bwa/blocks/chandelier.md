# Chandelier

![Chandelier](block:betterwithaddons:chandelier@0)

Chandeliers are fancy-looking light sources that can be hung from the ceiling. Any solid block can provide support for the chandelier. Alternatively, it can be attached to some rope.
When a chandelier loses support, it will fall, dealing damage to anyone standing underneath. The chandelier will pop off into an item on impact with the ground.