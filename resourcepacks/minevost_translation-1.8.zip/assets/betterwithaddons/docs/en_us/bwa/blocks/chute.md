# Chute

![Chute](block:betterwithaddons:chute@0)

The Chute is just like a Filtered Hopper, a box with a hole in it, but the Chute has several holes. When items are thrown into the top, they will pop out of the holes on the bottom, as one might expect: completely at random.
Outputs of the Chute can be blocked with solid blocks to refine the distribution.
When powered from the bottom, the Chute will change it's distribution to something more desirable: Round-Robin.

While the Chute can output even if unpowered, as opposed to the Filtered Hopper, it will only output to inventories if powered.