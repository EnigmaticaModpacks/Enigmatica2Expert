# Soaking Unit

![Soaking Unit](block:betterwithaddons:cherrybox@0)

The Soaking Unit is used to soak items in cold water. This process takes a long time, so you should probably build more than one. It must be placed in a specific way and only functions if all requirements are met.

![Schematic](betterwithaddons:docs/imgs/soakingbox.png)

Just as the drying Unit must be submerged in sand, the Soaking Unit must be submerged in water to function. The edge of a frozen stream is an ideal location to setup many Soaking Units.

This machine is used to make the following items:

![Soaked Bamboo](item:betterwithaddons:japanmat@6)
![Soaked Rice](item:betterwithaddons:japanmat@1)
![Soaked Mulberry Bark](item:betterwithaddons:japanmat@8)