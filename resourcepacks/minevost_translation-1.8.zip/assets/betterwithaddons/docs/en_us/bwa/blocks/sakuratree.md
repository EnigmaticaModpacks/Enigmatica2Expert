# Sakura Tree

![Sakura Sapling](block:betterwithaddons:sapling_sakura@0)

Sakura (or Cherry Blossom) is a very decorative tree, but its wood is a useful material for crafting items on an Ancestral Infuser. It does not occur naturally in the world and the Infuser must be used to create it from another sapling.
A single leaf falls from this tree for every soul that escapes the End.