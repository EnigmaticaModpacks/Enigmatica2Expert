# Lattice

![Lattice](block:betterwithaddons:lattice@0)

Only in the influence area of a [Worldscale](worldscale.md), Lattice blocks can be placed to increase the hardness (read: time to break) of adjacent blocks. In theory this is intended to make lesser building materials like stone viable for building protective structures, but this will require more tweaking in the future.
They can also be used as decorative blocks, of course.