# Thorny Vines

![Thorny Vine Seed](item:betterwithaddons:thorn_rose@0)

Thorny vines are an alien hybrid growth of cactus and rosebushes. They can be planted on either sand or mossy stonebricks. They will grow quite quickly and attempt to "hug" and grow around structures like walls, castles and enchanted wizard towers.

![Thorny Vines](betterwithaddons:docs/imgs/thorns.png)

They will frequently end in thorny roses, which can be used to synthesize even more seeds. The thorny vines will do significant damage to mobs and players, but will not destroy items. The vines themselves can be harvested for a green material named Midori.

![Thorny Rose](item:betterwithaddons:material@3)