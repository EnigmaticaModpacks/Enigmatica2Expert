# Alicio Tree

![Alicio Sapling](block:betterwithaddons:sapling_luretree@0)

Alicio Trees can be planted on any suitable soil. They will make a terrifying sound when they grow to maturity. Alicio Trees secrete a blood-red sap that attracts animals.
In order for them to attract animals, its grotesque face must be fed with items. See below for a table of food values.

![250 Munches](item:betterwithaddons:rotten_food@0)
![250 Munches](item:minecraft:rotten_flesh@0)
![500 Munches](item:minecraft:glowstone_dust@0)
![1000 Munches](item:betterwithaddons:material@3)
![(Mystery Meat) 4000 Munches](item:betterwithmods:mystery_meat@0)

The wood that Alicio Trees produce when chopped is unfortunately too spongy to be used for anything but fuel, but its terrifying face can be placed elsewhere as decoration.