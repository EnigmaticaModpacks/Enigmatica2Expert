# Drying Unit

#[Drying Unit](block:betterwithaddons:cherrybox@1)

The Drying Unit is used to dry wet items under the sun. This process takes a long time, so you should probably build more than one. It must be placed in a specific way and only functions if all requirements are met.

![Schematic](betterwithaddons:docs/imgs/dryingbox.png)

Additionally, the Drying Unit will not work in cold biomes or if the view to the sun is obstructed by blocks or clouds.
It will work twice as fast in very hot places.

This machine is used to make the following items:

![Bamboo Slats](item:betterwithaddons:japanmat@7)
![Rice Hay](item:betterwithaddons:japanmat@3)
![Mulberry Pulp](item:betterwithaddons:japanmat@9)


