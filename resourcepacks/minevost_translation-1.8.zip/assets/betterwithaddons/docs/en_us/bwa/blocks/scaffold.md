# Scaffold

![Scaffold](block:betterwithaddons:scaffold@0)

Scaffolds are useful tools for constructing vertical buildings like towers and mobtraps. They can be quickly stacked by right-clicking a placed scaffold with one in hand, but only up to a certain limit without a horizontally neighboring block providing support.
Additionally, they can be climbed just like ladders, and breaking the bottommost scaffold will break the whole stack.

Rope can also be attached to scaffolds to create [Rope Bridges](bridges.md).