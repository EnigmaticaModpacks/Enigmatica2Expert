# Ecksie Saplings

![Ecksie Sapling](block:betterwithaddons:ecksie_sapling@0)

Ecksie Saplings are special saplings, that won't grow any wooden logs. Instead, they grow a thin, wide carpet of leaves. Ecksie Saplings never stop growing, making them ideal for automated leaf farms.
Additionally, Ecksie Saplings will try to grow around solid objects, but will grow through liquids and weaker foliage like tall grass.

There may yet be other uses to such a curious plant.
In a twist of cruel fate, mainly due to its otherworldly nature, Bloodwood Saplings can not be made into Ecksie Saplings.