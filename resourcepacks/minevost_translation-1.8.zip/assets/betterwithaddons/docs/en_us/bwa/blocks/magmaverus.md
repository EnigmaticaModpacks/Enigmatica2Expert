# Magma Verus Block

![Magma Verus Block](block:betterwithaddons:elytra_magma@0)

Magma Verus Blocks are an odd block crafted from [Magma Cream Verus](../items/magmaverus.md). It appears to create a magical updrift when a player with an elytra flies over it.
