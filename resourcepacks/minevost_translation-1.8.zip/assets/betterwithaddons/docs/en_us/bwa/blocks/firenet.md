# Netted Screen (Melter)

![Schematic](betterwithaddons:docs/imgs/firenet.png)

(The block underneath the net can contain either fire or lava)

This design places some kind of meltable material in a bamboo basket above a heat source. Minerals with low melting points or mineral sands can thus be melted into small flakes.

This design is used to make the following items:

![Iron Scales](item:betterwithaddons:japanmat@12)