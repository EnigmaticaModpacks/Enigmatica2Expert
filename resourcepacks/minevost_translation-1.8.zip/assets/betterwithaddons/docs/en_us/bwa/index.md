# Better With Addons

Better With Addons is a modular compilation of successors to Better than Wolves addons. Pretty much everything can be turned on or off in the config.

## Content
* [Blocks](blocks/index.md)
* [Items](items/index.md)
* [Mechanics](mechanics/index.md)
* [Help! I'm on a skyblock map!](skyblock/index.md)