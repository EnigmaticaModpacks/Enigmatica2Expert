# Mechanics

 * [Ancestral Spirits](spirits.md)
 * [Karate Zombies](karate_zombies.md)