# Spirits

![Spirits](betterwithaddons:docs/imgs/spirits.png)

Spirits are small red orbs that float about 1 block from the ground after a [Karate Zombie](../mechanics/karate_zombies.md) releases them. They will be attracted to players holding glass bottles, and ${betterwithaddons.interaction.InteractionEriottoMod:SPIRIT_PER_BOTTLE} of them will be absorbed to fill one bottle.
Japanese Spirits can also be attracted to certain mobs, like Karate Zombies, or blocks, like Infused Soul Sand. Spirits are required to craft items at the Ancestral Infuser.