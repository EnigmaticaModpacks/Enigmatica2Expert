# Karate Zombies

![Karate Zombies](betterwithaddons:docs/imgs/karatezombie.png)

Karate Zombies spawn randomly in any place a regular Zombie would spawn. They're usually barely any stronger than an ordinary Zombie, but on death, they will release [spirits](../mechanics/spirits.md).
Additionally, Karate Zombies attract spirit orbs to themselves and absorb them on contact. This will increase their attack power and movement speed, and change their attire.
The more spirits they absorb, the more martial arts moves they will unleash on unsuspecting players, so be careful when fighting several at once.