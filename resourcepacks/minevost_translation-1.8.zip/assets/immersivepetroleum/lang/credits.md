LOCALIZATION
	- zh_CN: 3TUSK, DYColdWind
	- de_DE: Vexatos
	- ru_RU: McModder, lBlitzl
	- ja_JP: aiun